﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace insly.Utilities
{
    static class CommonFunctions
    {
        public static readonly Random getrandom = new Random();
        public static int GenarateRandom()
        {
            return getrandom.Next(1000, 10000);
        }
    }


}
