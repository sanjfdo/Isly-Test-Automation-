﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace insly.PageObjects.NewUser
{
    class ObjAddnewuser
    {
        private IWebDriver _Driver;

        public ObjAddnewuser(IWebDriver d)
        {
            _Driver = d;
        }

        public IWebElement Header { get { return _Driver.FindElement(By.XPath("/html/body/main/div/div/div/h1")); } }
        public IWebElement CountryDropdown { get { return _Driver.FindElement(By.Id("broker_address_country")); } }
        public IWebElement CompanyTextBox { get { return _Driver.FindElement(By.Id("broker_name")); } }
        public IWebElement ProfileDropdown { get { return _Driver.FindElement(By.Id("prop_company_profile")); } }
        public IWebElement NOEDropdown { get { return _Driver.FindElement(By.Id("prop_company_no_employees")); } }
        public IWebElement IamDropdown { get { return _Driver.FindElement(By.Id("prop_company_person_description")); } }
        public IWebElement EmailTextBox { get { return _Driver.FindElement(By.Id("broker_admin_email")); } }
        public IWebElement ManagerTextBox { get { return _Driver.FindElement(By.Id("broker_admin_name")); } }
        public IWebElement PhoneTextBox { get { return _Driver.FindElement(By.Id("broker_admin_phone")); } }
        public IWebElement PasswordLink { get { return _Driver.FindElement(By.XPath("//*[@id='field_broker_person_password']/td[2]/div/a")); } }
        public IWebElement PasswordOkButton { get { return _Driver.FindElement(By.XPath("/html/body/div[2]/div[3]/div/button")); } }
        public IWebElement TermsAndContidionsCheckBox { get { return _Driver.FindElement(By.XPath("//*[@id='field_terms']/td[2]/div/div/label[1]/span")); } }
        public IWebElement AgreePrivacyPolicyCheckBox { get { return _Driver.FindElement(By.XPath("//*[@id='field_terms']/td[2]/div/div/label[2]/span")); } }
        public IWebElement AgreeDataProcessingCheckBox { get { return _Driver.FindElement(By.XPath("//*[@id='field_terms']/td[2]/div/div/label[3]/span")); } }
        public IWebElement TermsAndConditionsLink { get { return _Driver.FindElement(By.XPath("//*[@id='field_terms']/td[2]/div/div/label[1]/a")); } }
        public IWebElement AgreeButton { get { return _Driver.FindElement(By.XPath("/html/body/div[2]/div[3]/div/button[1]")); } }
        public IWebElement PrivacyPolicyLink { get { return _Driver.FindElement(By.XPath("//*[@id='field_terms']/td[2]/div/div/label[2]/a")); } }
        public IWebElement PrivacyCloseButton { get { return _Driver.FindElement(By.XPath("/html/body/div[2]/div[1]/a/span")); } }
        public IWebElement SignupButton { get { return _Driver.FindElement(By.Id("submit_save")); } }

    }
}
