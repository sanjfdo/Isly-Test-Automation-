﻿using System;
using insly.PageObjects.NewUser;
using insly.Utilities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace insly
{
    [TestClass]
    public class SignUp
    {
        #region [Setup / TearDown]

        private TestContext testContextInstance = null;
        
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        IWebDriver MyDriver;
        string _Company;
        string _Profile;
        string _NOE;
        string _Iam;
        string _Email;
        string _Manager;
        string _Phone;

        //Use ClassInitialize to run code before running the first test in the class
        [ClassInitialize()]
        public static void MyClassInitialize(TestContext testContext)
        {
        }

        // Use TestInitialize to run code before running each test
        [TestInitialize()]
        public void MyTestInitialize()
        {
            
            MyDriver = new ChromeDriver(@"D:\ChromeDriver");
            MyDriver.Manage().Cookies.DeleteAllCookies();

            MyDriver.Manage().Window.Maximize();
            MyDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
 
        }

        [TestMethod]
        [DataSource("Microsoft.VisualStudio.TestTools.DataSource.CSV", "|DataDirectory|\\Data\\DataSheet.csv", "DataSheet#csv", DataAccessMethod.Sequential), DeploymentItem("Data\\DataSheet.csv")]
        public void AddNewUser()
        {
            MyDriver.Url = "https://signup.insly.com/signup";

            ObjAddnewuser objUser = new ObjAddnewuser(MyDriver);

            //Reading Data file
            ReadData();

            //Step1
            Assert.IsTrue(objUser.Header.Enabled);

            //Step2
            IWebElement CompanyName = objUser.CompanyTextBox;
            CompanyName.SendKeys(_Company);

            IWebElement Country = objUser.CountryDropdown;
            SelectElement SelectCountry = new SelectElement(Country);
            SelectCountry.SelectByValue("LK");

            IWebElement CompProfile = objUser.ProfileDropdown;
            SelectElement SelectProfile = new SelectElement(CompProfile);
            SelectProfile.SelectByIndex(4);

            IWebElement NOE = objUser.NOEDropdown;
            SelectElement SelectNOE = new SelectElement(NOE);
            SelectNOE.SelectByIndex(2);

            IWebElement Iam = objUser.IamDropdown;
            SelectElement SelectIam = new SelectElement(Iam);
            SelectIam.SelectByIndex(1);

            //Step3
            objUser.EmailTextBox.SendKeys(_Email);
            objUser.ManagerTextBox.SendKeys(_Manager);
            objUser.PasswordLink.Click();
            objUser.PasswordOkButton.Click();
            objUser.PhoneTextBox.SendKeys(_Phone);

            //Step4
            objUser.TermsAndContidionsCheckBox.Click();
            objUser.AgreePrivacyPolicyCheckBox.Click();
            objUser.AgreeDataProcessingCheckBox.Click();

            objUser.TermsAndConditionsLink.Click();
            objUser.AgreeButton.Click();

            objUser.PrivacyPolicyLink.Click();

            IJavaScriptExecutor jse = (IJavaScriptExecutor)MyDriver;
            jse.ExecuteScript("window.scrollTo(0,Math.max(document.documentElement.scrollHeight,document.body.scrollHeight,document.documentElement.clientHeight))", "");
            objUser.PrivacyCloseButton.Click();

            if (objUser.SignupButton.Enabled == true)
            {
                objUser.SignupButton.Click();
            }
        }

        private void ReadData()
        {
            int random;
            _Company = TestContext.DataRow["Company"].ToString();
            _Profile = TestContext.DataRow["Profile"].ToString();
            _NOE = TestContext.DataRow["NOE"].ToString();
            _Iam = TestContext.DataRow["Iam"].ToString();
            _Email = TestContext.DataRow["Email"].ToString();
            _Manager = TestContext.DataRow["Manager"].ToString();
            _Phone = TestContext.DataRow["Phone"].ToString();

            random = CommonFunctions.GenarateRandom();
            _Company = _Company + random.ToString();
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void MyTestCleanup()
        {

            
        }

        //Use ClassCleanup to run code after all tests in a class have run
        [ClassCleanup()]
        public static void MyClassCleanup()
        {
            
        }

        #endregion

    }
}
